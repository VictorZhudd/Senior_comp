const fs = require('fs');
const axios = require('axios');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

let ipfsArray = [];

// Read the contents of the folder
//path to export folder here
fs.readdir('', async (err, files) => {
  if (err) {
    console.error('Error reading directory:', err);
    return;
  }

  // Prepare CSV Writer
  const timestamp = Date.now();
  const csvWriter = createCsvWriter({
    //csvoutput folder path here
    path: `\\metadata_${timestamp}_${files.length % 1000}.csv`,
    header: [
      { id: 'id', title: 'ID' },
      { id: 'metadataPath', title: 'METADATA_PATH' },
    ],
  });

  const csvData = [];

  // Update the loop to iterate through the number of files in the folder
  for (let i = 0; i < files.length; i++) {
    let paddedHex = (
      '0000000000000000000000000000000000000000000000000000000000000000' +
      i.toString(16)
    ).substr(-64);

    const metadataPath = `metadata/${paddedHex}.json`;

    ipfsArray.push({
      path: metadataPath,
      content: {
        image: `/ipfs/QmRcz1Qw6QHEGCFFkRhccFCyGxzpzGmw5wDNo4Ayy56ChK/images/${paddedHex}.png`,
        name: `seniorproject #${i}`,
        description: 'Awesome NFT ',
      },
    });

    // Add the data to the CSV data array
    csvData.push({
      id: i,
      metadataPath,
    });
  }

  // Write the CSV data to file
  await csvWriter.writeRecords(csvData);
  console.log(`CSV file metadata_${timestamp}_${files.length % 1000}.csv has been created.`);

  axios
    .post(
      'https://deep-index.moralis.io/api/v2/ipfs/uploadFolder',
      ipfsArray,
      {
        headers: {
          // api key here
          'X-API-KEY': '',
          'Content-Type': 'application/json',
          accept: 'application/json',
        },
      }
    )
    .then((res) => {
      console.log(res.data);
    })
    .catch((error) => {
      console.log(error);
    });
});
