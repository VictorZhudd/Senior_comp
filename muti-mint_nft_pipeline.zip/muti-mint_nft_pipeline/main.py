import os
import subprocess

#put your export folder path there
folder_path = ""

# Rename files in the folder
files = os.listdir(folder_path)
for i, file in enumerate(files):
    padded_hex = ("0000000000000000000000000000000000000000000000000000000000000000" + hex(i)[2:]).zfill(64)
    src = os.path.join(folder_path, file)
    dst = os.path.join(folder_path, f"{padded_hex}.png")
    os.rename(src, dst)

# Full path to image.js
path_to_image1_js = ""

# Full path to metadata.js
path_to_metadata_js = ""

# Full path to minting.js
path_to_minting_js = ""

# Run image1.js
image1_result = subprocess.run(["node", path_to_image1_js], capture_output=True, text=True)

# Check for errors and print output
if image1_result.returncode != 0:
    print("Error in image1.js:")
    print(image1_result.stderr)
else:
    print("image1.js executed successfully:")
    print(image1_result.stdout)

# Run metadata.js
metadata_result = subprocess.run(["node", path_to_metadata_js], capture_output=True, text=True)

# Check for errors and print output
if metadata_result.returncode != 0:
    print("Error in metadata.js:")
    print(metadata_result.stderr)
else:
    print("metadata.js executed successfully:")
    print(metadata_result.stdout)

# Run minting.js
minting_result = subprocess.run(["node", path_to_minting_js], capture_output=True, text=True)

# Check for errors and print output
if minting_result.returncode != 0:
    print("Error in minting.js:")
    print(minting_result.stderr)
else:
    print("minting.js executed successfully:")
    print(minting_result.stdout)
