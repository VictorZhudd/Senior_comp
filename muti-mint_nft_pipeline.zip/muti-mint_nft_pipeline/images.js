const fs = require("fs").promises;
const axios = require("axios");
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const ipfsArray = [];
const promises = [];

// Specify the output folder and create a timestamped file name
// find csvoutput folder path here
const csvOutputFolder = "";
const timestamp = Date.now();
const csvFilename = `${timestamp}_ipfs.csv`;

// Initialize CSV Writer with the specified file name and headers
const csvWriter = createCsvWriter({
    path: `${csvOutputFolder}/${csvFilename}`,
    header: [
        { id: 'timestamp', title: 'TIMESTAMP' },
        { id: 'path', title: 'PATH' }
    ]
});

const csvData = [];

// Loop through the files and read them using fs.promises.readFile
// the path of the export folder here
const folderPath = '';

// Read the contents of the folder
fs.readdir(folderPath)
  .then(async files => {
    // Iterate through the files
    for (let i = 0; i < files.length; i++) {
      const fileName = files[i];

      promises.push(new Promise(async(res, rej) => {
          try {
              const data = await fs.readFile(`${folderPath}\\${fileName}`);
              const imagePath = `images/${fileName}`;

              ipfsArray.push({
                  path: imagePath,
                  content: data.toString("base64")
              });

              // Add the data to the CSV data array
              csvData.push({
                  timestamp: timestamp,
                  path: imagePath
              });

              res();
          } catch (err) {
              console.error(err);
              rej();
          }
      }));
    }

    // Move Promise.all(promises) inside the .then() block
    Promise.all(promises).then(async () => {
        // Write the CSV data to file
        await csvWriter.writeRecords(csvData);
        console.log(`CSV file ${csvFilename} has been created.`);

        // Upload the files to IPFS
        axios.post("https://deep-index.moralis.io/api/v2/ipfs/uploadFolder", 
            ipfsArray,
            {
                headers: {
                    // api-key here
                    "X-API-KEY": '',
                    "Content-Type": "application/json",
                    "accept": "application/json"
                }
            }
        ).then((res) => {
            console.log(res.data);
        })
        .catch((error) => {
            console.log(error);
        });
    }).catch((err) => {
        console.error(err);
    });

  })
  .catch(err => {
    console.error(err);
  });
