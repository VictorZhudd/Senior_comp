const { ethers } = require("ethers");
const fs = require('fs');
const path = require('path');

// Replace these with your provider and private key and contract address
const provider = new ethers.providers.JsonRpcProvider("");
const privateKey = "";
const contractAddress = "";

// ABI...
const abi = []
  

// Generate your URIs
const baseUri = "https://ipfs.moralis.io:2053/ipfs/QmNzqffPna7qv5nGx9qs3dBiWSEESEeavESbq3FSQwAyxs/metadata/";

let exportFolderPath = path.join(__dirname, 'export');

fs.readdir(exportFolderPath, (err, files) => {
  if (err) {
    return console.error(err);
  }

  let numFiles = files.length;

  for (let i = 0; i < numFiles; i++) {
    const paddedNumber = String(i).padStart(64, '0'); // Pad the number with zeros
    const metadataUrl = baseUri + paddedNumber + ".json";
    //put your account key from your wallet in there
    mintNFT("", i, metadataUrl).catch(console.error);
  }
});
